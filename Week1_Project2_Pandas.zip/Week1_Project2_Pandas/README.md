# Week 1 · Project 2 — Python and Pandas: PDF Library Analysis

**Objective:** Practise data filtering, grouping, sorting and merging with Pandas, continuing Project 1 "PDF Library in SQL".

**Tools:** Python, Pandas, Google Colab / Jupyter (keep only what you used).

**Dataset:** A PDF library table (title, author, category, pages, size in KB, year, reviewed status) created in code, plus two small tables (category reviewers, download counts) for merging.

## How to run
Upload `Week1_Python_Pandas_PDF.ipynb` to https://colab.research.google.com/ -> Runtime -> Run all.

## Work completed
20 exercises: inspect data, select columns, filter, sort, groupby summaries, a Large/Small label with `apply()`, and two merges.

## Learning outcomes
(Write in your own words after running.)

## Screenshots
(Add screenshots of selected outputs.)
